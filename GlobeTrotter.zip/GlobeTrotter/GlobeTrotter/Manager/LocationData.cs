﻿using GlobeTrotter.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace GlobeTrotter.App_Code
{
    public class Logement
    {
        public static List<CountryDataEntity> GetCountries()
        {

            var countries = new List<CountryDataEntity>();
            CountryDataEntity country;
            try
            {   // Open the text file using a stream reader.
                using (StreamReader sr = new StreamReader("/Data/sql-countries.csv"));//files[0].InputStream))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {

                        splitLine = line.Split(',');
                        if (splitLine == null) { continue; }

                        country = new CountryDataEntity();

                        country.Id = int.Parse(splitLine[0]);
                        country.CodeNumerique = string.IsNullOrEmpty(splitLine[1]) ? (int?)null : int.Parse(splitLine[1]);
                        country.Code2 = splitLine[2].ToString().ToUpper();
                        country.Code3 = splitLine[3].ToString().ToUpper();
                        country.LibelleFr = splitLine[4];
                        country.LibelleEn = splitLine[5];

                        countries.Add(country);
                    }
                }

                return countries;
            }
            catch (Exception ex)
            {
                throw string.Format("Une erreur est survenu ! Veuillez contacter le support !");
            }
        }

        //public static List<CityDataEntity> GetCitiesByCountry(string code2)
        //{

        //    var cities = new List<CityDataEntity>();
        //    CityDataEntity city;
        //    try
        //    {   // Open the text file using a stream reader.
        //        using (StreamReader sr = new StreamReader(files[0].InputStream))
        //        {
        //            string line;
        //            while ((line = sr.ReadLine()) != null)
        //            {

        //                splitLine = line.Split(',');
        //                if (splitLine == null || cpt == 0) { cpt++; continue; }

        //                city = new CityDataEntity();

        //                city.Id = int.Parse(splitLine[0]);
        //                city.

        //                cities.Add(city);
        //            }
        //        }

        //        return cities.Where(w => w.CodeCountry.ToUpper());
        //    }
        //    catch (Exception ex)
        //    {
        //        throw string.Format("Une erreur est survenu ! Veuillez contacter le support !");
        //    }
        //}
    }
}