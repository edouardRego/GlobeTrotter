﻿using System;
using System.Linq;

namespace GlobeTrotter.Common
{
    public class CityDataEntity
    {
        public int Id { get; set; }
        public string CodeCountry { get; set; }
        public string City { get; set; }
        public string CodePostal { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
    }
}