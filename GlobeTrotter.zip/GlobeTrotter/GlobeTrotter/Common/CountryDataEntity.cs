﻿using System;
using System.Linq;

namespace GlobeTrotter.Common
{
    public class CountryDataEntity
    {
        public int Id { get; set; }
        public int? CodeNumerique { get; set; }
        public string Code2 { get; set; }
        public string Code3 { get; set; }
        public string LibelleFr { get; set; }
        public string LibelleEn { get; set; }
    }
}