﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GlobeTrotter.Common
{
    public class HotelDataEntity
    {
        public int Id { get; set; }
        public string Code2 { get; set; }
        public string City { get; set; }
        public string Titre { get; set; }
        public string Sexe { get; set; }
        public string PrenomNom { get; set; }
        public string Alias { get; set; }
        public DateTime Date { get; set; }
        public string Libelle { get; set; }
        public string Commentaire { get; set; }
        public int Note { get; set; }
        public string Image
        {
            get
            {
                var val = "/Images/Profils/avatar.png";
                if (string.IsNullOrEmpty(Alias) && string.IsNullOrEmpty(PrenomNom))
                    return val;
                else
                    return string.Format("/Images/Profils/{0}_{1}.jpg",Sexe.ToLower(),Alias);
            }
        }
        public string GetNote
        {
            get
            {
                return string.Format("{0}/10", Note);
            }
        }
    }
}