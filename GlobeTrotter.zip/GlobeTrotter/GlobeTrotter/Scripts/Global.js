﻿/*var rdCbCountries;
var rdCbCities;
Sys.Application.add_load(function (e) {
    rdCbCities = $find('<%= rdCbCities.ClientID %>');
    rdCbCountries = $find('<%= rdCbCountries.ClientID %>');
});

function bindCities() {
    var id = rdCbCountries.get_selectedItem().get_value();
    alert(id);
    PageMethods.LoadCities(id, function (result) {

        rdCbCities.clearItems();

        var items = result;

        if (items.length == 0) {
            var comboItem = new Telerik.Web.UI.RadComboBoxItem();
            comboItem.set_text("Aucun résultat");
            comboItem.set_value("null");
            rdCbCities.get_items().add(comboItem);
            rdCbCities.set_text("");
        }

        for (var i = 0; i < items.length; i++) {
            var item = items[i];

            var comboItem = new Telerik.Web.UI.RadComboBoxItem();
            comboItem.set_text(item.City);
            comboItem.set_value(item.Id);
            rdCbCities.get_items().add(comboItem);
        }
    });
}*/