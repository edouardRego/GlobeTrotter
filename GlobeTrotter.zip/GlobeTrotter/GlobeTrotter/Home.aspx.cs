﻿using System.IO;
using System.Text.RegularExpressions;
using GlobeTrotter.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;
using Telerik.Web.UI;
using System.Web.Services;
using System.Web.Script.Services;

namespace GlobeTrotter
{
    public partial class _Default : Page
    {
        private const string libSessionAllCountries = "AllCountries"; //new JavaScriptSerializer().Serialize("AllCountries");
        private const string libSessionAllCities = "AllCities";// new JavaScriptSerializer().Serialize("AllCities");
        private const string libSessionAllPost = "AllPost";// new JavaScriptSerializer().Serialize("AllCities");

        protected List<CountryDataEntity> ListCountries
        {
            get
            {
                return Session[libSessionAllCountries] == null ? GetCountries() : Session[libSessionAllCountries] as List<CountryDataEntity>;
            }
            set
            {
                Session[libSessionAllCountries] = value;
            }
        }

        protected List<CityDataEntity> ListCities
        {
            get
            {
                return Session[libSessionAllCities] == null ? GetCities() : Session[libSessionAllCities] as List<CityDataEntity>;
            }
            set
            {
                Session[libSessionAllCities] = value;
            }
        }

        protected List<HotelDataEntity> ListPost
        {
            get
            {
                return Session[libSessionAllPost] == null ? GetPost() : Session[libSessionAllPost] as List<HotelDataEntity>;
            }
            set
            {
                Session[libSessionAllPost] = value;
            }
        }
        
        [WebMethod]
        [ScriptMethod]
        public static List<CityDataEntity> LoadCities(string id)
        {
            var countries = HttpContext.Current.Session[libSessionAllCountries] as List<CountryDataEntity>;
            var cities = HttpContext.Current.Session[libSessionAllCities] as List<CityDataEntity>;
            var citiesToReturn = new List<CityDataEntity>();

            if (countries == null || cities == null) return null;

            int idCountry = 0;
            int.TryParse(id, out idCountry);

            if (idCountry != 0)
            {
                var country = countries.Where(w => w.Id == idCountry).FirstOrDefault();
                citiesToReturn.AddRange(country == null ? cities : cities.Where(w => w.CodeCountry.ToUpper() == country.Code2).ToList());
            }
            else
                citiesToReturn.AddRange(cities);

            return citiesToReturn;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CheckRights();

                LoadCountries();

                LoadCities();
            }
        }
 
        /// <summary>
        /// Check des droits
        /// </summary>
        private void CheckRights()
        {
            // Redirection vers la page de login
            if (!Context.User.Identity.IsAuthenticated)
                Response.Redirect("/Account/Login.aspx");
        }

        #region LOADING
        private void LoadCountries()
        {
            rdCbCountries.DataSource = ListCountries;
            rdCbCountries.DataTextField = "LibelleFr";
            rdCbCountries.DataValueField = "Id";
            rdCbCountries.DataBind();

            rdCbCountries.Items.Insert(0, new RadComboBoxItem("", ""));
        }

        private void LoadCities()
        {
            BindListCities(null);
        }

        /// <summary>
        /// Chargement des villes
        /// </summary>
        /// <param name="idCountry"></param>
        private void BindListCities(int? idCountry)
        {
            var cities = new List<CityDataEntity>();
            if (idCountry.HasValue)
            {
                var country = ListCountries.Where(w => w.Id == idCountry).FirstOrDefault();
                cities.AddRange(country == null ? ListCities : ListCities.Where(w => w.CodeCountry.ToUpper() == country.Code2).ToList());
            }
            else
                cities.AddRange(ListCities);

            rdCbCities.DataSource = cities;
            rdCbCities.DataTextField = "City";
            rdCbCities.DataValueField = "Id";
            rdCbCities.DataBind();

            rdCbCities.Items.Insert(0, new RadComboBoxItem("",""));
        }

        /// <summary>
        /// Chargements des post
        /// </summary>
        /// <param name="city"></param>
        private void BindListPost(CityDataEntity city)
        {
            divZonePost.Visible = true;
            rdLvResult.DataSource = ListPost.Where(w => w.City.ToUpper().Equals(city.City.ToUpper()));
            rdLvResult.DataBind();
        }
        #endregion

        #region DATA
        /// <summary>
        /// Récupération des pays
        /// </summary>
        /// <returns></returns>
        private static List<CountryDataEntity> GetCountries()
        {
            string[] splitLine;
            var countries = new List<CountryDataEntity>();
            CountryDataEntity country;
            try
            {   // Open the text file using a stream reader.
                using (StreamReader sr = new StreamReader(HttpContext.Current.Server.MapPath("~/Data/sql-countries.csv")))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {

                        splitLine = line.Split(';');
                        if (splitLine == null) { continue; }

                        country = new CountryDataEntity();

                        country.Id = int.Parse(splitLine[0]);
                        country.CodeNumerique = string.IsNullOrEmpty(splitLine[1]) ? (int?)null : int.Parse(splitLine[1]);
                        country.Code2 = splitLine[2].ToString().ToUpper();
                        country.Code3 = splitLine[3].ToString().ToUpper();
                        country.LibelleFr = splitLine[4];
                        country.LibelleEn = splitLine[5];

                        countries.Add(country);
                    }
                }

                return countries.OrderBy(o => o.LibelleFr).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Une erreur est survenu ! Veuillez contacter le support !"));
            }
        }
        
        /// <summary>
        /// Récupération des villes
        /// </summary>
        /// <returns></returns>
        private static List<CityDataEntity> GetCities()
        {
            string[] splitLine;
            var cities = new List<CityDataEntity>();
            CityDataEntity city;
            try
            {   // Open the text file using a stream reader.
                using (StreamReader sr = new StreamReader(HttpContext.Current.Server.MapPath("~/Data/sql-cities.csv")))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {

                        splitLine = line.Split(';');
                        if (splitLine == null) { continue; }

                        city = new CityDataEntity();

                        city.Id = int.Parse(splitLine[0]);
                        city.CodeCountry = splitLine[1];
                        city.City = splitLine[3];
                        city.CodePostal = splitLine[4];
                        city.Latitude = decimal.Parse(splitLine[5].Replace(".",","));
                        city.Longitude = decimal.Parse(splitLine[6].Replace(".", ","));

                        cities.Add(city);
                    }
                }

                return cities.OrderBy(o => o.City).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Une erreur est survenu ! Veuillez contacter le support !"));
            }
        }

        /// <summary>
        /// Récupération des post
        /// </summary>
        /// <returns></returns>
        private static List<HotelDataEntity> GetPost()
        {
            string[] splitLine;
            var hotels = new List<HotelDataEntity>();
            HotelDataEntity hotel;
            DateTime dDate;
            try
            {   // Open the text file using a stream reader.
                using (StreamReader sr = new StreamReader(HttpContext.Current.Server.MapPath("~/Data/sql-hotels.csv")))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {

                        splitLine = line.Split(';');
                        if (splitLine == null) { continue; }

                        hotel = new HotelDataEntity();

                        hotel.Id = int.Parse(splitLine[0]);
                        hotel.Code2 = splitLine[1];
                        hotel.City = splitLine[2];
                        hotel.Sexe = splitLine[3];
                        hotel.PrenomNom = splitLine[4];
                        hotel.Alias = splitLine[5];
                        hotel.Titre = splitLine[6];
                        var dateString = splitLine[7].ToString().Replace("-", "/");
                        DateTime.TryParse(dateString, out dDate);
                        hotel.Date = dDate;
                        hotel.Libelle = splitLine[8];
                        hotel.Commentaire = splitLine[9];
                        hotel.Note = string.IsNullOrEmpty(splitLine[10]) ? 0 : int.Parse(splitLine[10]);

                        hotels.Add(hotel);
                    }
                }

                return hotels.OrderByDescending(o => o.Note).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Une erreur est survenu ! Veuillez contacter le support !"));
            }
        }
        #endregion 

        #region EVENTS
        /// <summary>
        /// Chargement des villes en fonction du pays sélectionné
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rdCbCountries_SelectedIndexChanged(object sender, Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs e)
        {
            int? idCountry = string.IsNullOrEmpty(e.Value) ? (int?)null : int.Parse(e.Value);
            BindListCities(idCountry);
        }

        /// <summary>
        /// Lancement de la recherche et affichage
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Get city selected
            int idCity = int.Parse(rdCbCities.SelectedValue);
            var city = ListCities.Where(w => w.Id == idCity).FirstOrDefault();
            // Recherche des posts fait sur le blog
            BindListPost(city);
        }
        
        /// <summary>
        /// Suppression des filtres
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lnkbtnErase_Click(object sender, EventArgs e)
        {
            divZonePost.Visible = false;
            rdCbCities.SelectedValue = string.Empty;
            rdCbCountries.SelectedValue = string.Empty;
            rdLvResult.Rebind();
        }
        #endregion
    }
}