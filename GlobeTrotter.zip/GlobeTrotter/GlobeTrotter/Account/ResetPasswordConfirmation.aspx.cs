﻿using System.Web.UI;

namespace GlobeTrotter.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}